import setuptools

setuptools.setup(
    name="pygame_utils_likeablejuniper",
    version="0.1.0",
    description="Package which provides some basic GUI elements for pygame",
    url="https://github.com/LikeableJuniper/pygame_utils",
    author="LikeableJuniper",
    license="MIT License",
    packages=["pygame_utils_likeablejuniper"],
    install_requires=[
        "pygame-ce"
    ]
)