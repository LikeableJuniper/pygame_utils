from dataclasses import dataclass
from typing import Iterable
import pygame as pg

from pygame_utils_likeablejuniper.core.element import GUIElement
from pygame_utils_likeablejuniper.layout.layout import Layout, LayoutParams
from pygame_utils_likeablejuniper.style.style import Border, Style, merge_styles


@dataclass
class ContainerStyle(Style):
    """
    A style property with value None indicates that it should just be the default value.
    """
    background_color: pg.typing.ColorLike | None = None
    border: Border | None = None

@dataclass
class CompleteContainerStyle(Style):
    """
    Always needs all fields to be non-None. Is used for defining fallback values and the result of merge_styles()
    """
    background_color: pg.typing.ColorLike
    border: Border
    
    def apply(self, target: 'Container | None' = None):
        if target:
            target.style = self
        else:
            Container.default_style = self

DEFAULT_CONTAINER_STYLE = CompleteContainerStyle((0, 0, 0, 0), Border(0, (0, 0, 0)))

class Container(GUIElement):
    default_style: CompleteContainerStyle = DEFAULT_CONTAINER_STYLE
    def __init__(self, rect: list[float], layout: Layout | None = None, elements: list[GUIElement] | None = None, style: ContainerStyle | None = None):
        self.layout = layout
        if self.layout:
            self.layout.set_rect(rect)
        self.elements = elements or []
        super().__init__(rect, style, Container.default_style)
        self.style = merge_styles(style, Container.default_style)
    
    def update(self, events: Iterable[pg.Event], dt: float):
        super().update(events, dt)
        for element in self.elements:
            if element.enabled:
                element.update(events, dt)
    
    def draw(self, screen: pg.Surface):
        super().draw(screen)

        for element in self.elements:
            if element.visible:
                element.draw(screen)
    
    def add(self, element: GUIElement):
        if isinstance(element, GUIElement):
            self.elements.append(element)
            self._rerender()
        else:
            raise TypeError("Can only add GUIElement to Container")

    def set_rect(self, rect: list[float]):
        if self.layout:
            self.layout.set_rect(rect)
        super().set_rect(rect)

    def set_layout_params(self, layout_params: LayoutParams):
        if self.layout:
            self.layout.layout_params = layout_params
            self._rerender()

    def _rerender(self):
        super()._rerender()
        if self.layout:
            self.layout.apply(self.elements)